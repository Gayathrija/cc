import {} from "../variables";

/* ==========================================================================
    Container

    Default Class For Mendix Container Widget
========================================================================== */

export const Container = {
    container: {
        // All ViewStyle properties are allowed
    },
};

export const ScrollContainer = {
    container: {
        // All ViewStyle properties are allowed
    },
};
