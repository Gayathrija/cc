/* ==========================================================================
    Web View

    Default Class For Mendix Web View Widget
========================================================================== */

export const com_mendix_widget_native_webview_WebView = (WebView = {
    container: {
        // All ViewStyle properties are allowed
    },
    errorContainer: {
        // All ViewStyle properties are allowed
    },
    errorText: {
        // All TextStyle properties are allowed
    },
});
